import os
import random
import cv2
import numpy as np
import pandas as pd
import scipy.io
import matplotlib.pyplot as plt
from pathlib import Path
from PIL import Image
import tensorflow as tf
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.decomposition import PCA
import tflearn
from tflearn.layers.conv import conv_2d, max_pool_2d
from tflearn.layers.core import input_data, dropout, fully_connected
from tflearn.layers.estimator import regression
from sklearn import svm, metrics
from sklearn.ensemble import RandomForestClassifier
import pickle


class convnet_class:
    def __init__(self,imsize,data_train,data_val,numlayer,neuron,model_name,color=1):
        tf.reset_default_graph()
        self.imsize = imsize
        self.color = color
        self.Y = [i[1] for i in data_train]
        self.Y_val = [i[1] for i in data_val]
        if color ==1:
            self.X = np.array([i[0] for i in data_train]).reshape([-1, imsize, imsize, 3])
            self.X_val = np.array([i[0] for i in data_val]).reshape([-1, imsize, imsize, 3])
            self.convnet = input_data(shape=[None, imsize, imsize, 3], name='input')
        else:
            self.X = np.array([i[0] for i in data_train]).reshape([-1, imsize, imsize, 1])
            self.X_val = np.array([i[0] for i in data_val]).reshape([-1, imsize, imsize, 1])
            self.convnet = input_data(shape=[None, imsize, imsize, 1], name='input')
        
        for ly in range(0,numlayer):
            self.convnet = conv_2d(self.convnet, neuron[ly], 2, activation='relu')
            self.convnet = max_pool_2d(self.convnet, 2)

        self.convnet = dropout(self.convnet, 0.7)
        
        self.convnet = fully_connected(self.convnet, 2, activation='softmax')
        self.convnet = regression(self.convnet, optimizer='adam', learning_rate=0.0001, loss='categorical_crossentropy', name='targets')
        
        self.model = tflearn.DNN(self.convnet,tensorboard_dir = "log")
        if os.path.exists('{}.meta'.format(model_name)):
            self.model.load(model_name)
            print('model loaded!')
        else:
            self.model.fit({'input': self.X}, {'targets': self.Y}, n_epoch=20, validation_set=({'input': self.X_val}, {'targets': self.Y_val}), 
            snapshot_step=500, show_metric=True, run_id=model_name)
            self.model.save(model_name)
    
    def test_predict(self,inp_data):
        if self.color ==1:
            self.X_test = np.array([i[0] for i in inp_data]).reshape([-1, self.imsize, self.imsize, 3])
        else:
            self.X_test = np.array([i[0] for i in inp_data]).reshape([-1, self.imsize, self.imsize, 1])
        self.Y_test_pred_nn = np.round(self.model.predict(self.X_test))

    def model_perf(self):
        self.Y_train_pred_nn = np.round(self.model.predict(self.X))
        self.Y_val_pred_nn = np.round(self.model.predict(self.X_val))
        self.train_acc =   metrics.accuracy_score(np.array(self.Y),self.Y_train_pred_nn)
        self.train_pres =   metrics.precision_score(np.array(self.Y),self.Y_train_pred_nn,average=None)[0]
        self.train_recall =   metrics.recall_score(np.array(self.Y),self.Y_train_pred_nn,average=None)[0]
        self.train_fscore =   metrics.f1_score(np.array(self.Y),self.Y_train_pred_nn,average=None)[0]
        self.train_auc =   metrics.roc_auc_score(np.array(self.Y),self.Y_train_pred_nn,average=None)[0]
        self.val_acc =   metrics.accuracy_score(np.array(self.Y_val),self.Y_val_pred_nn)
        self.val_pres =   metrics.precision_score(np.array(self.Y_val),self.Y_val_pred_nn,average=None)[0]
        self.val_recall =   metrics.recall_score(np.array(self.Y_val),self.Y_val_pred_nn,average=None)[0]
        self.val_fscore =   metrics.f1_score(np.array(self.Y_val),self.Y_val_pred_nn,average=None)[0]
        self.val_auc =   metrics.roc_auc_score(np.array(self.Y_val),self.Y_val_pred_nn,average=None)[0]

