import os
import random
import cv2
import numpy as np
import pandas as pd
import scipy.io
import matplotlib.pyplot as plt
from pathlib import Path
from PIL import Image
import tensorflow as tf
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.decomposition import PCA
import tflearn
from tflearn.layers.conv import conv_2d, max_pool_2d
from tflearn.layers.core import input_data, dropout, fully_connected
from tflearn.layers.estimator import regression
from sklearn import svm, metrics
from sklearn.ensemble import RandomForestClassifier
import pickle


##class for RF classification
class rf_class:
    def __init__(self,data_train,data_val,model_name,n_estimators=500):
        row,col = np.shape(data_train)
        self.row = row
        self.col = col
        self.X = np.array(data_train[:,0:col-2])
        self.Y = data_train[:,col-2:col]
        self.X_val = np.array(data_val[:,0:col-2])
        self.Y_val = data_val[:,col-2:col]
        if os.path.exists('{}.sav'.format(model_name)):
            filename = '{}.sav'.format(model_name)
            self.rfmodel = pickle.load(open(filename, 'rb'))
            print('RF model loaded!')
        else:
            self.rfmodel = RandomForestClassifier(min_samples_leaf=2,n_estimators=500, n_jobs=-1)
            self.rfmodel.fit(self.X,self.Y)
           # save the model to disk
            filename = '{}.sav'.format(model_name)
            pickle.dump(self.rfmodel, open(filename, 'wb'))
            
        self.Y_train_pred_rf = self.rfmodel.predict(self.X)
        self.Y_val_pred_rf = self.rfmodel.predict(self.X_val)
        self.train_acc =   metrics.accuracy_score(self.Y,self.Y_train_pred_rf)
        self.train_pres =   metrics.precision_score(self.Y,self.Y_train_pred_rf,average=None)[0]
        self.train_recall =   metrics.recall_score(self.Y,self.Y_train_pred_rf,average=None)[0]
        self.train_fscore =   metrics.f1_score(self.Y,self.Y_train_pred_rf,average=None)[0]
        self.train_auc =   metrics.roc_auc_score(self.Y,self.Y_train_pred_rf,average=None)[0]
        self.val_acc =   metrics.accuracy_score(self.Y_val,self.Y_val_pred_rf)
        self.val_pres =   metrics.precision_score(self.Y_val,self.Y_val_pred_rf,average=None)[0]
        self.val_recall =   metrics.recall_score(self.Y_val,self.Y_val_pred_rf,average=None)[0]
        self.val_fscore =   metrics.f1_score(self.Y_val,self.Y_val_pred_rf,average=None)[0]
        self.val_auc =   metrics.roc_auc_score(self.Y_val,self.Y_val_pred_rf,average=None)[0]
    
    def test_predict(self,inp_data):
        row,col = np.shape(inp_data)
        if col != self.col:
            print('The features of input test data do not match with training data')
        else:
            self.X_test = np.array(inp_data[:,0:col-2])
            self.Y_test_pred_rf = self.rfmodel.predict(self.X_test)