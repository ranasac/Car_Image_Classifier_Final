import os
import random
import cv2
import numpy as np
import pandas as pd
import scipy.io
import matplotlib.pyplot as plt
from pathlib import Path
from PIL import Image
import tensorflow as tf
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.decomposition import PCA
import tflearn
from tflearn.layers.conv import conv_2d, max_pool_2d
from tflearn.layers.core import input_data, dropout, fully_connected
from tflearn.layers.estimator import regression
from sklearn import svm, metrics
from sklearn.ensemble import RandomForestClassifier
import pickle


def augment_data(trdata, augementation_factor=1, use_random_rotation=True, use_random_shear=True, use_random_shift=True, use_random_zoom=True):
    augmented_image = []
    augmented_image_labels = []
    final_aug_image = []
    ct=-1

    for num in range (0, len(trdata)):
        dataset = trdata[num][0]
        dataset_labels = trdata[num][1]

        for i in range(0, augementation_factor):
                # original image:
                ct += 1
                augmented_image.append(dataset)
                augmented_image_labels.append(dataset_labels)
                final_aug_image.append([np.array(augmented_image[ct]), np.array(augmented_image_labels[ct])])
    
    
                if use_random_rotation:
                    augmented_image.append(tf.contrib.keras.preprocessing.image.random_rotation(dataset, 20, row_axis=0, col_axis=1, channel_axis=2))
                    augmented_image_labels.append(dataset_labels)
                    ct += 1
                    final_aug_image.append([np.array(augmented_image[ct]), np.array(augmented_image_labels[ct])])
                        
    
                if use_random_shear:
                    augmented_image.append(tf.contrib.keras.preprocessing.image.random_shear(dataset, 0.2, row_axis=0, col_axis=1, channel_axis=2))
                    augmented_image_labels.append(dataset_labels)
                    ct += 1
                    final_aug_image.append([np.array(augmented_image[ct]), np.array(augmented_image_labels[ct])])
    
    
                if use_random_shift:
                    augmented_image.append(tf.contrib.keras.preprocessing.image.random_shift(dataset, 0.2, 0.2, row_axis=0, col_axis=1, channel_axis=2))
                    augmented_image_labels.append(dataset_labels)
                    ct += 1
                    final_aug_image.append([np.array(augmented_image[ct]), np.array(augmented_image_labels[ct])])
                
#                if use_random_zoom:
#                    augmented_image.append(tf.contrib.keras.preprocessing.image.random_zoom(dataset, 0.9, row_axis=0, col_axis=1, channel_axis=2))
#                    augmented_image_labels.append(dataset_labels)
#                    ct += 1
#                    final_aug_image.append([np.array(augmented_image[ct]), np.array(augmented_image_labels[ct])])


    return final_aug_image



#Convert into RGB Scale
def rgb2gray(datalist):
    out_data = []
    for i in range(0,len(datalist)):
        r, g, b = datalist[i][0][:,:,0], datalist[i][0][:,:,1], datalist[i][0][:,:,2]
        grimg = 0.2989 * r + 0.5870 * g + 0.1140 * b
        out_data.append([np.array(grimg),np.array(datalist[i][1])])
    return out_data

def stdimage(datalist,maxfeature=255):
    out_data = []
    for i in range(0,len(datalist)):
        img = np.divide(datalist[i][0],maxfeature)
        out_data.append([np.array(img),np.array(datalist[i][1])])
    return out_data

def pcafun(datalist,imsize=50,scaler=None,pca=None,train=0,val=0,test=0):
    inp_mat = np.zeros(shape=(len(datalist),imsize*imsize))
    label_mat = np.zeros(shape=(len(datalist),2))
    for i in range(0,len(datalist)):
        inp_mat[i,:] = datalist[i][0].reshape(1,imsize*imsize)
        if test == 0:
            label_mat[i,0] = datalist[i][1][0]
            label_mat[i,1] = datalist[i][1][1]
        else:
            label_mat[i,0] = 0
            label_mat[i,1] = 0
    if train == 1:
        scaler = StandardScaler()
        pca = PCA(.95)
        scaler.fit(inp_mat)
        inp_mat_std = scaler.transform(inp_mat)
        pca.fit(inp_mat_std)
    else:
        inp_mat_std = scaler.transform(inp_mat)
    img_inp = pca.transform(inp_mat_std)
    row,col = np.shape(img_inp)
    out_mat = np.zeros(shape=(row,col+2))
    out_mat = np.c_[img_inp,label_mat]
    return scaler,pca,out_mat