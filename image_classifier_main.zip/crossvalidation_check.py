# -*- coding: utf-8 -*-
"""
Created on Sat Jul 14 10:55:01 2018

@author: ranas
"""


import os, sys
import random
import cv2
import numpy as np
import pandas as pd
import scipy.io
import matplotlib.pyplot as plt
from pathlib import Path
from PIL import Image
import tensorflow as tf
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import MinMaxScaler
from sklearn.decomposition import PCA
import tflearn
from tflearn.layers.conv import conv_2d, max_pool_2d
from tflearn.layers.core import input_data, dropout, fully_connected
from tflearn.layers.estimator import regression
from sklearn import svm, metrics
from sklearn.ensemble import RandomForestClassifier
import pickle
from sklearn.model_selection import train_test_split

ROOT_PATH = os.path.dirname(os.path.abspath(__file__))
os.chdir(ROOT_PATH)
from func_class_package.load_images import load_images, load_test_images
from func_class_package.preprocess_image import augment_data, rgb2gray, stdimage, pcafun
from  func_class_package.cnn_class_cv import convnet_class
from  func_class_package.rf_class_cv import rf_class
from  func_class_package.ensemble_model import ensemble_model, model_perf

#class datapath:
#    def __init__(self,path_train_1,path_train_0,path_val_1,path_val_0):
#        self.default_path = os.getcwd()
        
        
default_path = ROOT_PATH
path_train_1 = os.path.join(default_path,"Images","car-train")
path_train_0 = os.path.join(default_path,"Images","notcar-train")
path_val_0 = os.path.join(default_path,"Images","notcar-validate")
path_val_1 = os.path.join(default_path,"Images","car-validate")

## To change directory
#os.chdir(path)
imsize = 50
maxfeature = 255
## Load input data

if (os.path.exists("training_data.npy")):
    training_data = np.load("training_data.npy")
else:
    training_data_1 = load_images(path_train_1,[1,0],imsize)
    training_data_0 = load_images(path_train_0,[0,1],imsize)
    training_data = training_data_1 + training_data_0
    random.shuffle(training_data)
    np.save("training_data.npy", training_data)

if (os.path.exists("validation_data.npy")):
    validation_data = np.load("validation_data.npy")
else:
    validation_data_1 = load_images(path_val_1,[1,0],imsize)
    validation_data_0 = load_images(path_val_0,[0,1],imsize)
    validation_data = validation_data_1 + validation_data_0
    random.shuffle(validation_data)
    np.save("validation_data.npy", validation_data)

#img = Image.fromarray(training_data[5][0], 'RGB')
##img.save('my.png')
#img.show()
num_fold = 10
training_data_all = training_data
val_acc_mat = np.zeros(shape=(num_fold,5))
val_pres_mat = np.zeros(shape=(num_fold,5))
val_recall_mat = np.zeros(shape=(num_fold,5))
val_fscore_mat = np.zeros(shape=(num_fold,5))
val_auc_mat = np.zeros(shape=(num_fold,5))
for num_cv in range(0,num_fold):
    training_data, validation_data= train_test_split(training_data_all, test_size=0.33, random_state=num_cv)
        
    
    aug_training_data = augment_data(training_data,augementation_factor=2)
    
    
    
    #img = Image.fromarray(aug_training_data[2][0], 'RGB')
    ###img.save('my.png')
    #img.show()
    
    training_gray_data = rgb2gray(aug_training_data)
    training_std_color_data = stdimage(aug_training_data,maxfeature)
    training_std_gray_data = stdimage(training_gray_data,maxfeature)
    
    scaler, pca, training_pca_data = pcafun(training_gray_data,imsize,train=1)
    
    val_gray_data = rgb2gray(validation_data)
    val_std_color_data = stdimage(validation_data,maxfeature)
    val_std_gray_data = stdimage(val_gray_data,maxfeature)
    vals,valp,val_pca_data = pcafun(val_gray_data,imsize=imsize,scaler=scaler,pca=pca,val=1)
    
    #plt.imshow(training_gray_data[5][0])
    model_name_color = '{}_model'.format('colornet_cv')
    colornet = convnet_class(imsize=imsize,data_train=training_std_color_data,data_val=val_std_color_data,numlayer=4,neuron=[32,64,200,1024],model_name=model_name_color,color=1)
    colornet.model_perf()
    val_acc_mat[num_cv,0] = colornet.val_acc
    val_pres_mat[num_cv,0] = colornet.val_pres
    val_recall_mat[num_cv,0] = colornet.val_recall
    val_fscore_mat[num_cv,0] = colornet.val_fscore
    val_auc_mat[num_cv,0] = colornet.val_auc
    
    model_name_gray = '{}_model'.format('graynet_cv')
    graynet = convnet_class(imsize=imsize,data_train=training_std_gray_data,data_val=val_std_gray_data,numlayer=4,neuron=[32,64,200,1024],model_name=model_name_gray,color=0)
    graynet.model_perf()
    val_acc_mat[num_cv,1] = graynet.val_acc
    val_pres_mat[num_cv,1] = graynet.val_pres
    val_recall_mat[num_cv,1] = graynet.val_recall
    val_fscore_mat[num_cv,1] = graynet.val_fscore
    val_auc_mat[num_cv,1] = graynet.val_auc
    
    
    rf_model_name = '{}_model'.format('rfpca_cv')
    rf = rf_class(data_train=training_pca_data,data_val=val_pca_data,model_name=rf_model_name,n_estimators=500)
    val_acc_mat[num_cv,2] = rf.val_acc
    val_pres_mat[num_cv,2] = rf.val_pres
    val_recall_mat[num_cv,2] = rf.val_recall
    val_fscore_mat[num_cv,2] = rf.val_fscore
    val_auc_mat[num_cv,2] = rf.val_auc
    
    Y_val_ens_pred = ensemble_model(colornet.Y_val_pred_nn,graynet.Y_val_pred_nn,rf.Y_val_pred_rf)
    ens_val_acc, ens_val_pres, ens_val_recall, ens_val_fscore, ens_val_auc =  model_perf(np.array(colornet.Y_val), Y_val_ens_pred)
    val_acc_mat[num_cv,3] = ens_val_acc
    val_pres_mat[num_cv,3] = ens_val_pres
    val_recall_mat[num_cv,3] = ens_val_recall
    val_fscore_mat[num_cv,3] = ens_val_fscore
    val_auc_mat[num_cv,3] = ens_val_auc
        
np.save("cv_accuracy.npy", val_acc_mat)   
np.save("cv_precision.npy", val_pres_mat) 
np.save("cv_recall.npy", val_recall_mat) 
np.save("cv_fscore.npy", val_fscore_mat) 
np.save("cv_auc.npy", val_auc_mat) 

df_cv = pd.DataFrame({'Models': ["Color_Convnet","Gray_Convnet","Random_Forest","Ensemble"], 'Accuracy': np.mean(val_acc_mat, axis=0)[0:4], 'Precision': np.mean(val_pres_mat, axis=0)[0:4], 'Recall': np.mean(val_recall_mat, axis=0)[0:4], 'F1score': np.mean(val_fscore_mat, axis=0)[0:4], 'AUC': np.mean(val_auc_mat, axis=0)[0:4] })
# multiple line plot

plt.scatter( 'Models', 'Accuracy', data=df_cv,  s=20, c='b', marker="s")
plt.scatter( 'Models', 'Precision', data=df_cv,  s=20, c='k', marker="o")
plt.scatter( 'Models', 'Recall', data=df_cv,  s=20, c='g', marker="+")
plt.scatter( 'Models', 'F1score', data=df_cv,  s=20, c='r', marker=">")
plt.scatter( 'Models', 'AUC', data=df_cv,  s=20, c='c', marker="d")
plt.legend()
# Add titles
plt.title("Crossvalidation Performance", loc='left', fontsize=12, fontweight=0, color='orange')
plt.xlabel("ML Models")
plt.ylabel("Score")